#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

def a( x):
    return x*2

def b( x):
    return x*3

def c( x):
    return x*5

flist= [ a, b, c]    # �Լ� �ڿ� ����
la = [ 4, 11, 6, 7, 8]

for w in la :
    X =  flist[w%3]
    print w, X,
    print "f(x)=", X( w )