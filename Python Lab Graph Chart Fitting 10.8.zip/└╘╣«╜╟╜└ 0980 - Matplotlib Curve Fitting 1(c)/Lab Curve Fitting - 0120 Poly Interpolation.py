#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt

points = np.array([(1, -4), (2, -20), (5, 12), (9, -10)])

x = points[:,0]           # get x and y vectors
y = points[:,1]


fx3 = np.polyfit(x, y, 3)   # calculate 3�� polynomial
print "ã�� ���׽� = ", fx3
f   = np.poly1d( fx3 )  # ���׽�

# calculate new x's and y's
x_new = np.linspace(x[0], x[-1], 50)
y_new = f(x_new)

plt.plot(x,y,'o', x_new, y_new)
plt.xlim([x[0]- 2, x[-1] + 2 ])
plt.ylim(-50, 50)
plt.show()