#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt

x = [1, 2, 3,  8]
y = [3, 5, 7, 10]

fit_1 = np.polyfit(x,y,1)  # 1���� mapping ��. ����� 2 ��
print "Linear Fitted data = ", fit_1
fit_fn1 = np.poly1d(fit_1)
# fit_fn is now a function which takes in x and returns an estimate for y

plt.plot(x,y, 'ro', x, fit_fn1(x), '--k')

plt.xlim(0, 10)
plt.ylim(0, 12)
plt.show( )