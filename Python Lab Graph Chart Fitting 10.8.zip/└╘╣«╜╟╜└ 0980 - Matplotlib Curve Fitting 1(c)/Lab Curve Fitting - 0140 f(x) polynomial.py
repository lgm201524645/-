#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt

p = np.poly1d([ 1, -3, -5, 6])  #f(x)=1x^3 -3 x^2 - 5x + 6
x = np.linspace(-3, 4, 10)
y = p(x)
plt.plot(x, y, 'o-')
plt.show()


