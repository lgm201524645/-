#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

import matplotlib.pyplot as plt
matplotlib.rc('font', family='NanumGothic')  # �ѱ� ��Ʈ ����

plt.text(0.2, 0.5, "Winter", size=50, rotation=30.,
         ha="center", va="center",
         bbox=dict(boxstyle="round",
                   ec=(1., 0.5, 0.5), # ���ڻ���
                   fc=(1., 0.8, 0.2), # ������
                   )
         )

plt.text( 0.8, 0.5, "Summer", size=50, rotation=-30.,
         ha="right", va="top",
         bbox=dict(boxstyle="square",
                   ec=(1., 0.2, 0.8),
                   fc=(1., 0.8, 0.8),
                   )
         )


plt.draw()
plt.show()