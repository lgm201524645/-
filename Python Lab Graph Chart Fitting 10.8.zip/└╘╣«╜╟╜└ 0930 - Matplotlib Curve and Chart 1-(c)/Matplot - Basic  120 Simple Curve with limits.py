#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

import matplotlib.pyplot as plot

x = [1, 2, 3, 4, 8,15]    # x��
y = [1, 4, 9, 16, 25, 17] # �ش�Ǵ� y=f(x) ��

plot.ylim(0, 40)
plot.xlim(-3,20)
plot.plot(x, y)
plot.show() # show the plot on the screen