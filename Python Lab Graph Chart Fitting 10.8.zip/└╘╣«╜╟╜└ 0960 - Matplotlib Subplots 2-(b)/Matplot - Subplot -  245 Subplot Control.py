import matplotlib.pyplot as plt
import numpy as np
import math


plt.figure(figsize=(6,5))

plt.subplot(221)
plt.grid()


plt.subplot(222)
plt.subplot(212)

plot.show()