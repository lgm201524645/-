#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

import matplotlib.pyplot as plt

plt.plot([1, 2, 3, 4], [1, 4, 9, 16], 'ro') # red with 'o' mark
plt.axis([0, 6, 0, 20])  # x���� [0,6], y���� [0,20]

plt.ylabel('Y-value PLOT')
plt.show()