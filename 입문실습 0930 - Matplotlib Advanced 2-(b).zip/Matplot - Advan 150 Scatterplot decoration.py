#-*- coding: cp949 -*-
#-------------------------------------------------------------------------------
# Purpose:     2018 Power Python
# Author:      Cho
#-------------------------------------------------------------------------------

# scatterplot.py
import numpy as np
import pylab as pl
import matplotlib

from matplotlib import font_manager, rc
font_name = font_manager.FontProperties(fname="c:/Windows/Fonts/NanumGothic.ttf").get_name()
rc('font', family=font_name)



pl.xlabel('���⿡ ���̺��� ǥ��')
pl.ylabel( 'y���� ���⿡ �����ϴ�.')
# You can make a title for your plot by:
pl.title( '�ѱ��� �Ǵ��� ���ô�.')

#You can change the x and y ranges displayed on your plot by:
pl.xlim(0, 10)
pl.ylim(0, 40)

# Make an array of x values
x = [1, 2, 3, 4, 5]
# Make an array of y values for each x value
y = [1, 4, 9, 16, 25]
# use pylab to plot x and y as red circles

pl.plot(x, y, 'ro')
# show the plot on the screen
pl.show()

