#!/usr/bin/python

import matplotlib.pyplot as plt
import numpy as np

y = np.random.randn(1000)

plt.hist(y, rwidth=0.9)
#plt.savefig('7900_03_07.png')
plt.show()

plt.clf() # clear current figure
plt.hist(y, 20, rwidth=0.9) # histogram�� 20���� ������.
plt.show()