#!/usr/bin/python

import matplotlib.pyplot as plt
plt.title("A Plotting with axis Labeling")
x=[5, 3, 7, 2, 4, 1]
plt.plot(x)
plt.xticks(range(len(x)), ['Jan', 'Feb', 'March', 'Apr', 'May', 'June'])
plt.yticks(range(1, 8, 2), ['good', 'fair', 'average', 'bad'])
plt.show()
