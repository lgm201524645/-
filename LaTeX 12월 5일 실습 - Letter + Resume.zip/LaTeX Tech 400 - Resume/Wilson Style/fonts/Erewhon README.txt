The Erewhon font can be found at http://www.ctan.org/tex-archive/fonts/erewhon

Erewhon is based on the Heuris­tica pack­age, which is based in turn on Utopia. Erewhon adds a num­ber of new fea­tures — small caps in all styles rather than just reg­u­lar, added fig­ure styles (pro­por­tional, in­fe­rior, nu­mer­a­tor, de­nom­i­na­tor) and su­pe­rior let­ters. The size is 6% smaller than Heuris­tica, match­ing that of Utopi­aStd.

Li­cense: The SIL Open Font Li­cense
Main­tainer: Michael Sharpe
